## Recursos/Comandos do Bot

### 🖼️ Figurinhas
- Foto para sticker
- Video/GIF para sticker
- Sticker para foto
- Renomear sticker
- EmojiMix
- Auto sticker

### 📥 Downloads 
- Youtube (video/audio)
- Facebook (video)
- Instagram (video/imagem)
- X (video/imagem)
- Tiktok (video)
- Google (imagem)

### ⚒️ Utilidades Gerais
- Brasileirão A/B
- Lista de animes atuais
- Lista de mangás atuais
- Têndencias de filmes/séries
- Encurtar links
- Upload de imagens
- Efeitos de aúdio
- Texto para voz
- Áudio para texto
- Letra de música
- Reconhecimento de músicas
- Detector de DDD
- Consulta de clima e previsão do tempo
- Conversão de moedas
- Calculadora
- Pesquisa web    
- Detector de anime
- Noticias atuais
- Tradutor de texto

### 👾 Variado
- Pedra, papel e tesoura
- Cara e coroa
- Viadômetro
- Gadômetro
- Bafômetro
- Detector de mentira
- Compartibilidade de par
- Casal
- Frases do WhatsApp Jr.
- Chance
- Top 5
- Roleta Russa


### 👨‍👩‍👦‍👦 Administração de Grupo
- Promover/rebaixar participante
- Adicionar/remover participante
- Marcar todos
- Marcar participantes 
- Marcar admins
- Obter link do grupo
- Redefinir link do grupo
- Obter dono do grupo
- Lista negra
- Mutar grupo para não usar comandos
- Bem vindo
- Auto sticker
- Anti fake
- Anti link
- Anti flood
- Filtro da palavras proibidas
- Sistema de avisos (3 avisos e vai para a lista negra)
- Contagem de mensagens
- Ranking dos membros com mais mensagens do grupo
- Marcar inativos 
- Bloquear/desbloquear comandos no grupo
- Apagar mensagens
- Abrir/fechar grupo para admins


### ⚙️ Administração de Dono
- Entrar em grupo
- Sair de grupo
- Sair de todos os grupos
- Anúncio para os grupos
- Bloquear/desbloquear usuário
- Bloquear/desbloquear comandos globalmente
- Modo admin para apenas admins usarem comandos
- Ligar/desligar comandos no privado do bot
- Limitar comandos por minuto
- Auto sticker em mensagens privadas
- Obter usuários bloqueados
- Modificar foto do bot
- Modificar descrição/recado do bot
- Modificar nome do bot
- Promover/rebaixar usuários
  