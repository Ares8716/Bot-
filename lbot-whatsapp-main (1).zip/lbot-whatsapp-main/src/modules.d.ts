declare module 'node-webpmux';
declare module 'pretty-num';
declare module 'node-gtts';
declare module '@vreden/youtube_scraper';
declare module 'emoji-mixer';
